package com.ecommerce.itemservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ecommerce.itemservice.model.Item;

@Repository
public interface ItemRepository extends JpaRepository<Item, Long> {
	List<Item> findByCategory(String category);

	List<Item> findByNameContainingIgnoreCase(String name);

	boolean existsByNameAndCategory(String name, String category);
}
