package com.ecommerce.inventoryservice.services;

import java.time.LocalDateTime;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ecommerce.inventoryservice.dto.InventoryDTO;
import com.ecommerce.inventoryservice.exceptions.InventoryNotFoundException;
import com.ecommerce.inventoryservice.model.Inventory;
import com.ecommerce.inventoryservice.repository.InventoryRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class InventoryServiceImpl implements InventoryService {

    private final InventoryRepository inventoryRepository;

    @Override
    public InventoryDTO addInventory(InventoryDTO dto) {
        Inventory inventory = Inventory.builder()
                .itemId(dto.getItemId())
                .quantity(dto.getQuantity())
                .warehouseLocation(dto.getWarehouseLocation())
                .lastUpdated(LocalDateTime.now())
                .build();
        return toDTO(inventoryRepository.save(inventory));
    }

    @Override
    public InventoryDTO updateInventory(Long id, InventoryDTO dto) {
        log.info("Updating inventory ID: {}", id);
        
        Inventory inventory = inventoryRepository.findById(id)
                .orElseThrow(() -> new InventoryNotFoundException("Inventory not found with id: " + id));
        
        inventory.setQuantity(dto.getQuantity());
        inventory.setWarehouseLocation(dto.getWarehouseLocation());
        inventory.setLastUpdated(LocalDateTime.now());
        
        Inventory updated = inventoryRepository.save(inventory);
        
        log.info("Successfully updated inventory ID: {}", id);
        return toDTO(updated);
    }

    @Override
    @Transactional(readOnly = true)
    public InventoryDTO getInventoryByItemId(Long itemId) {
        return inventoryRepository.findByItemId(itemId)
                .map(this::toDTO)
                .orElseThrow(() -> new InventoryNotFoundException("No inventory for item ID: " + itemId));
    }

    @Override
    public void deleteInventory(Long id) {
        if (!inventoryRepository.existsById(id)) {
            throw new InventoryNotFoundException("Record not found with id: " + id);
        }
        inventoryRepository.deleteById(id);
    }

    private InventoryDTO toDTO(Inventory entity) {
        return InventoryDTO.builder()
                .id(entity.getId())
                .itemId(entity.getItemId())
                .quantity(entity.getQuantity())
                .warehouseLocation(entity.getWarehouseLocation())
                .lastUpdated(entity.getLastUpdated())
                .build();
    }
}