package com.ecommerce.inventoryservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerce.inventoryservice.dto.InventoryDTO;
import com.ecommerce.inventoryservice.services.InventoryService;

import io.swagger.v3.oas.annotations.Operation;

@RestController
@RequestMapping("/api/inventory")
@CrossOrigin(originPatterns = "*", allowCredentials = "true")
public class InventoryController {

	@Autowired
	private InventoryService inventoryService;

	@PostMapping
	@PreAuthorize("hasAnyAuthority('SCOPE_sre', 'SCOPE_devopsengineer')")
	@Operation(summary = "Add inventory for an item")
	public ResponseEntity<InventoryDTO> addInventory(@RequestBody InventoryDTO dto) {
		return new ResponseEntity<>(inventoryService.addInventory(dto), HttpStatus.CREATED);
	}

	@GetMapping("/item/{itemId}")
	@PreAuthorize("hasAnyAuthority('SCOPE_sre', 'SCOPE_devopsengineer')")
	@Operation(summary = "View inventory levels for a specific item")
	public ResponseEntity<InventoryDTO> getInventoryByItemId(@PathVariable Long itemId) {
		return ResponseEntity.ok(inventoryService.getInventoryByItemId(itemId));
	}

	@PutMapping("/{id}")
	@PreAuthorize("hasAnyAuthority('SCOPE_sre', 'SCOPE_devopsengineer')")
	@Operation(summary = "Update inventory records")
	public ResponseEntity<InventoryDTO> updateInventory(@PathVariable Long id, @RequestBody InventoryDTO inventoryDTO) {
		return ResponseEntity.ok(inventoryService.updateInventory(id, inventoryDTO));
	}

	@DeleteMapping("/{id}")
	@PreAuthorize("hasAnyAuthority('SCOPE_sre', 'SCOPE_devopsengineer')")
	@Operation(summary = "Remove inventory records")
	public ResponseEntity<Void> deleteInventory(@PathVariable Long id) {
		inventoryService.deleteInventory(id);
		return ResponseEntity.noContent().build();
	}
}