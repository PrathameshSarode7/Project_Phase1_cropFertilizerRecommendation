package com.ecommerce.inventoryservice.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration

public class SwaggerConfiguration implements WebMvcConfigurer {

	@Override

	public void addCorsMappings(CorsRegistry registry) {

		registry.addMapping("/**")

				.allowedOrigins("http://localhost:3000", "http://localhost:4200")

				.allowedMethods("GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS")

				.allowedHeaders("*")

				.allowCredentials(true);

	}

}
