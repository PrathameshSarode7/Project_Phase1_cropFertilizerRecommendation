package com.ecommerce.inventoryservice.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableMethodSecurity
public class SecurityConfig {

	@Bean
	public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
	    http.csrf(AbstractHttpConfigurer::disable) // Ensure CSRF is disabled for APIs
	        .authorizeHttpRequests(req -> req
	            .requestMatchers("/api/**").authenticated() // Protect all inventory APIs [cite: 181]
	            .anyRequest().permitAll())
	        .oauth2ResourceServer(oauth -> oauth.jwt(Customizer.withDefaults()));
	    return http.build();
	}
    }